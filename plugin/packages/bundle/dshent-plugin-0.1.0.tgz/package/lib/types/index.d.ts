/**
 * [INPUT]: 依赖 Cordis/Schemastery、Harness credentials/LLM/subprocess/inventory、官方运行时身份与企业业务模块
 * [OUTPUT]: 对外提供 Web/Desktop 共用 bundle apply、默认关闭的插件验签开关、Host 凭据持久化、企业插件安装/卸载与条件 Session 同步注册
 * [POS]: bundle 的唯一 Host Loader 入口，组合平台认证、官方企业模型与环境原生插件调和；Session 同步仅在 sessionPolicy.enabled 时挂载
 * [PROTOCOL]: 变更时更新此头部，然后检查 CLAUDE.md
 */
import type { Context } from '@deepseek-ai/cordis';
import type { CredentialProvider } from '@deepseek-ai/dsh-credentials';
import { type LlmRuntime } from '@deepseek-ai/dsh-llm';
import z from '@deepseek-ai/schemastery';
import { type WebServerRoutePort } from '@dshent/platform-client';
import { type PluginDistributionContext } from '@dshent/plugin-distribution';
import { type SessionPersistencePort, type SessionStorePort } from '@dshent/session-sync';
export declare const name = "owndsh";
export declare const inject: string[];
export interface Config {
    /** 可选安装默认值；用户可在欢迎页写入 Harness 官方 settings。 */
    readonly baseUrl?: string;
    /** 默认关闭；开启后使用安装配置的公钥验证企业插件签名。 */
    readonly verifyPluginSignatures?: boolean;
    /** 仅开启验签时读取的 Ed25519 SPKI PEM 或 DER Base64；bootstrap 无权替换。 */
    readonly trustedPluginPublicKey?: string;
    readonly requestTimeoutMs: number;
    readonly disposeTimeoutMs: number;
    readonly profile: string;
    readonly dshCommand: string;
}
export declare const Config: z<Config>;
interface EnterpriseHostContext extends Context {
    readonly webServer: WebServerRoutePort;
    readonly credentials: CredentialProvider;
    readonly llm: LlmRuntime;
    readonly subprocess: PluginDistributionContext['subprocess'];
    readonly pluginInventory: PluginDistributionContext['pluginInventory'];
    readonly sessions?: SessionStorePort;
    readonly sessionPersistence?: SessionPersistencePort;
}
/** 在 Harness 官方 Service 上挂载平台控制面并配置官方 dsh-llm-pi-ai。 */
export declare function apply(ctx: EnterpriseHostContext, config: Config): void;
export {};
//# sourceMappingURL=index.d.ts.map